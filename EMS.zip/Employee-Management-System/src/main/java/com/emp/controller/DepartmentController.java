package com.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.emp.model.Department;
import com.emp.repository.DepartmentRepository;
import com.emp.service.DepartmentService;


@Controller
public class DepartmentController {
	 @Autowired
	     DepartmentService departmentService;
	 @Autowired
	     DepartmentRepository departmentRepository;
	 
	 @GetMapping("add1")
	 public String add1() {
		 return "new_department";
	 }

	    // display list of departments
	    @GetMapping("departmentlist")
	    public String viewHomePage(Model model,Department department) {
	       List<Department>depart= departmentRepository.findAll();
	    	model.addAttribute("depart",depart);
	        return "dept_list";
	    }
	    //@OneToMany
	    @GetMapping("/showNewDepartmentForm")
	    public String showNewDepartmentForm(Model model) {
	        // create model attribute to bind form data
	       Department department = new Department();
	        model.addAttribute("departments", department);
	        return "new_department";
	    }

	    @GetMapping("insert1")
	    public String saveDepartment( Department department) {
	        // save department to database
	    	departmentRepository.save( department);
	        return "new_department";
	    }
	    
	    @GetMapping("before")
	    public String before(){
	    return "dept_list";
	    }
	    
	    @GetMapping("update")
	    public String showDepartmentForUpdate() {
	    	return "update_department";
	    }
	    
	    @GetMapping("saveDepartment")
	    public String saveUpdate(Department department) {
	    	departmentRepository.save(department);

	         return "update_department";
	    }

	    @GetMapping("delete")
	    public String deleteDepartment(@RequestParam long departmentID) {

	        // call delete department method 
	        this.departmentService.deleteDepartmentById(departmentID);
	        return "index";
	    }

       
	    
	    
	    
	   
}
