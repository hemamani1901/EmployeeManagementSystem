package com.emp.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.emp.model.Department;

@Service
public interface DepartmentService {
	
    List < Department > getAllDepartment();
    
    void saveDepartment(Department department);
    
    Department getDepartmentById(long id);
    
    void deleteDepartmentById(long id);

   


}